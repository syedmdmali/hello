﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloworldDataLayer.DataHelper
{
    public class DbHelper : IDbHelper
    {
        public ResponseData GetData()
        {
            return new ResponseData { Data = DateTime.Now.ToString() };
        }
    }
}
