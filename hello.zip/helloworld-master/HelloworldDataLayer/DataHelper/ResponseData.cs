﻿namespace HelloworldDataLayer.DataHelper
{
    public class ResponseData
    {
        public string Data { get; set; }
    }
}