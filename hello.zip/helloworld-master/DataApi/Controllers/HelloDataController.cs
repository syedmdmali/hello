﻿using HelloworldDataLayer.DataHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DataApi.Controllers
{
    public class HelloDataController : ApiController
    {

        private readonly IDbHelper _dbHelper;
        public HelloDataController(IDbHelper dbHelper)
        {
            _dbHelper = dbHelper;

        }
        // GET api/values
        public ResponseData  Get()
        {
            return _dbHelper.GetData();
        }
    }
}
