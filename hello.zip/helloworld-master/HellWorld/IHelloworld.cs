﻿namespace HellWorld
{
    public interface IHelloworld
    {
        void Main(string[] args);
    }
}