﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HellWorld.Service
{
    class HelloAppServiceHelper : IHelloAppServiceHelper
    {  
        /// <summary>
       ///     The Rest client
       /// </summary>
        private readonly IRestClient restClient;

        /// <summary>
        ///     The Rest request
        /// </summary>
        private readonly IRestRequest restRequest;

        public HelloAppServiceHelper(
              IRestClient restClient,
              IRestRequest restRequest    )
        {
            this.restClient = restClient;
            this.restRequest = restRequest;
           
        }
        public ResponseData GetData()
        {
            ResponseData res = null;

            this.restRequest.Resource = "HelloData";
            this.restRequest.Method = Method.GET;
            restClient.BaseUrl = new Uri("http://localhost:58964/api/");
            // Clear the request parameters
            this.restRequest.Parameters.Clear();

            // Execute the call and get the response
            var response = this.restClient.Execute<ResponseData>(this.restRequest);

            // Check for data in the response
            if (response != null)
            {
                // Check if any actual data was returned
                if (response.Data != null)
                {
                    res = response.Data;
                }
                else
                {
                    res = new ResponseData { Data = DateTime.Now.ToString() };

                }
            }
            else
            {
                // Log the exception
                const string ErrorMessage =  "Did not get any response from the Hello World Web Api for the Method: GET /todaysdata";
            }

            return res;

        }
    }
}
