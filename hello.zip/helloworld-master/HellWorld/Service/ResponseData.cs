﻿namespace HellWorld.Service
{
    public class ResponseData
    {
        public string Data { get; set; }
    }
}