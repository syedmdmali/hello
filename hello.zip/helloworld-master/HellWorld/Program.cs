﻿using HellWorld.Service;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;
using Unity.Injection;
using Unity.Lifetime;

namespace HellWorld
{
    class Program 
    {
        public static void Main(string[] args)
        {
            using (var container = new UnityContainer())
            {
                // Configure depenency injection
                container.RegisterType<IHelloAppServiceHelper, HelloAppServiceHelper>(new HierarchicalLifetimeManager());
                container.RegisterType<IHelloworld, HelloWorld>(new HierarchicalLifetimeManager());
                container.RegisterType<IRestClient, RestClient>(new ContainerControlledLifetimeManager(),
                                               new InjectionConstructor());
                container.RegisterType<IRestRequest, RestRequest>(new ContainerControlledLifetimeManager(),
                                               new InjectionConstructor());
                // Run the main program
                container.Resolve<IHelloworld>().Main(args);
            }
        }
    }
}
