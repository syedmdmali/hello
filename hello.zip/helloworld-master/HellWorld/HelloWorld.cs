﻿using HellWorld.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HellWorld
{
    class HelloWorld : IHelloworld
    {
        private readonly IHelloAppServiceHelper _helloAppServiceHelper ;

        public HelloWorld(IHelloAppServiceHelper helloAppServiceHelper)
        {
            _helloAppServiceHelper = helloAppServiceHelper;
        }
        public void Main(string[] args)
        {
            var res = _helloAppServiceHelper.GetData();
            Console.WriteLine("Hello World {0}", res.Data);
            Console.ReadKey();
        }
    }
}
